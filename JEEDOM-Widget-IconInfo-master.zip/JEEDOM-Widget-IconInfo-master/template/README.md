<h1><b>Templates pour Nouvelles Icônes</b></h1>

<p><i>IconInfo_template.pfi</i>: Template de création d'icônes utilisable avec le logiciel Photofiltre.</br>
Contient des calques à rendre visibles ou non selon le visuel désiré ainsi que des calques de texte haut et bas.

<p><i>IconInfo_template.psd</i>: Template de création d'icônes utilisable avec le logiciel Photoshop.</br>
Non testé
